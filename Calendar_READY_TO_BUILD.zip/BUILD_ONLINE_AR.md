# بناء Calendar كـ APK من الهاتف

هذه الحزمة ليست لـ Demo2APK. هي مشروع Android Native.

## الطريقة الأسهل باستخدام GitHub
1. أنشئ مستودعًا جديدًا في GitHub.
2. ارفع مجلد `CalendarWhatsAppNative` كاملًا إلى المستودع.
3. افتح تبويب **Actions**.
4. اختر **Build Calendar APK**.
5. اضغط **Run workflow** إذا لم يبدأ البناء تلقائيًا.
6. بعد انتهاء البناء افتح التشغيل الناجح ثم قسم **Artifacts**.
7. نزّل `Calendar-debug-apk`، ثم فك الضغط وستجد `app-debug.apk`.

ملاحظة: لا تحتاج إلى Demo2APK لهذه النسخة.
